#include <stdio.h>
#include <stdlib.h>


int main() {
    FILE *f = fopen("hello.txt", "w");

    if (f == NULL) {
        printf("Hiba a fajl megnyit�sakor!\n");
        return 1;
    }

    fprintf(f, "Hello World\n");

    //fclose(f);

    printf("A szoveg sikeresen kiirva a hello.txt fajlba.\n");

    return 0;
}
